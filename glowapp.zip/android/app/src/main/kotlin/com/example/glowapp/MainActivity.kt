package com.example.glowapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
