import 'package:flutter/material.dart';
import 'package:glowapp/screens/WelcomeScreen.dart';

void main() {
  runApp(const CosmeticApplicationOnlineShop());
}

class CosmeticApplicationOnlineShop extends StatelessWidget {
  const CosmeticApplicationOnlineShop({Key? key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: WelcomeScreen(),
    );
  }
}
