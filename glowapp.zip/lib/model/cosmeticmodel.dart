class Cosmetic {
  String name;
  String details;
  String pictureURL;
  int cosmeticPrice;

  Cosmetic({
    required this.name,
    required this.details,
    required this.pictureURL,
    required this.cosmeticPrice,
  });
}
