import 'package:flutter/material.dart';
import 'cosmetic_list.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.lightBlueAccent,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Logo Image
              ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Image.network(
                  'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAO4AAADUCAMAAACs0e/bAAABIFBMVEX///8AAADfaKj//v/8///6/////f/k5OT///38/Pz4///daqbeaafp6enb29v8//3svNbhX6bs2eXjZqjV1dVcXFzcYaHeZqnlosTDw8OEhITKysr29vY3NzfvxdrfaaZpaWn33+x8fHykpKRycnKHh4dCQkKXl5e9vb2zs7MeHh5WVlYvLy/58/mZmZkrKyvfjLrbe6/u4+wSEhLy1Ojnu9DWcKbgYqz47vTiWaHbXZu0tLRISEioqKjst9bglb7QgKvWk7nUfrTSaqTvzt7cpMblkrnRlrfad7Hxps3bbqL75O7dfKrRq8Pl0uLVn7fbtMTPiazsrNDwts/txODxut7p3u3PZpnawc750+fchLvckMPkVqjvn7v6z+Xjeq7OxCc9AAAQ/ElEQVR4nO1cjV/ayLpOyCQkk8AQohmQyJfgZ6OAAROroAv0WLW2q1zb3Xvu8v//F3dmkkC0dnfPHq1Nf/O0lWQySd9n3nfej8mgIHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcPy4kCRJAQhCxXWBDJH02vK8LCRBBlBqDEfX83nn/W+ujF5bohcF0aYyOzNsbIwzhmEMpq762iK9JFQVlEzLymTIP4v8s7su+IkNGqigmyFkMyF0S+/91HQlYYgXdA3d+kUBEnhtqZ4PVHVqYn4qsGcv6OoZu0B89U9DV1VVJAsCEhIWCzpmphbRxfiRqyJx6nvL+JxAyOmf/1IFaoLuLLD0kK5ljF5RtucHAt7YDgJDU5cGq7oDHHkqbHtP3KN9RwGfF6gxtoyMbk6gkmidmlS7BqHbURJphgT983fvRueykNrJ/K+AatEsgQQD4NnMLWcsc5YcBlU6N2uZ4FeQ3vn7wWRzdOAntAjcs7DVGrhJuqhom3pN76lqWukiZXRM1GgY1YR2JThkdLFZkpVFuwQc72KMgyFU05tHq+6ZTRyT0UnQVWHjoju/uJgPios2oClgVpu9H184ryDlc0FWZP8swAa+9BONmnx1ddVoXPXgMuiqqKdf33+YNVCKawakQNQbWIRuQmkAgandLRaLH9xlo4pKwQS65w9ceNpANKXKnm3/y5s6mhw1Ev2VMLFu0F9SU1HDxoPCzSS1MSgGhFdeter0wYKuIJSMjiqBPlgYLpDOsG4EHSXt9ZGkqOij7suTXuxwQ7pIkBN0hT5JpI/GDZTemBuBZA29YARhHyGJWjeja//u++4w0jcQZH9wRJKvW6QqaadLIN8eF+FsgpSY7tTG48FgHF1Gqjw1aTLi/tlD0gMV6t1z+8IP3S7TLjasjB1dViBLK+1Jqt3yEkCqBrZhTqFCzZfSzeCMgXF8WaZZpdVBP8k6rKrBa9PAhsvqQFUVphjjcYbRVSUFTIhysdF7ZSmfDUghwdcyrBFLoyhdXa8d12r0moqAq+tWxpy+spDPB1kS4PmRnrG9WLsmzmBshmmIMA0w9VNpzjBUJVQkK3kkWYANWilca6xRIFHIdfwJBCQqy1c6PrLsgsx6CqmsdhUoQUQAQeRsVXB7lDGCPmGkqrIMFAXJEJCUC8GOpY+tTtSPkk0hX1DoUBRgbKLQHWTwUZfUDND37kqjd6NpoeHICiyalqHXPEhJShLxznIK+Xr2kWmaOCjGmbIKZ9g8v5Ll+1LXNDO2bVmWPb91odbo2nYpzCcBanSKaVRvIVx+s6sxXWLOnRJE7rltWrWaPpjPdcscZ+wCKYk7hh9mzyoqBsdTV5bllCUcC7oJf+tK0BsEGb0znEwmN96sWpgHODjzoTuBYQ9VLZpGcHYvKClbwHmKLhIKtjU+uyn0b3q+7xer/dmshs1BAyhJumPruABTTpe+CUITG9vDyScf0LcpJKH09E5jZOBxL06WKd2aRW7r+N9+9I+IBd3onAQY0LOxWe3fRC1IaIwNc+y9t/G1Fg0KIHTZqzLz/DWE/ud4TFeWFKVjmbNCL/ZdsmdYhtnt37zLBHECGdE1MqaerhzrMV2kwOpxcF4tLl4B3euZsXXpgC9ed2xF5UFENzPG+msI/c/xmK6AtG5Gv+mHJ4qMGvhobF27Arz6tWqaHxF71RnTNdJOVyUlvPH+U7ReAQXPID557pAUSzcLHevSl2lu8fPQlW9N21uEpXudlERdFym+Pr79UrBxFf5UdDW5a8095qdICtEg1e/R3IfA0c1bOLkPyE86Ej8PXcXGoz5bZ0TC/ZiU89cuAP4c32mwd6NbHSD/THNX8I/xsMAWzQFhW8NdB0nOPLhFSHYnHaurwZ+Kbi/AX+5Y9uSNcQ1fOCr0L/EtIgqH1ZI10GgemWK6bPeFXY2SX3AV4P4d0GgudTw+6roA+YNgKtFKSJmMzIGWcmN+SFd1j/FtX4DAGxxhPHeR7NfwncKWWv1q1zxDPwfduESANu58caGnW2M88JHkD3ApqnsaxLxHqaar9u0MxtjWY+1KcsfSvV6D5I0WjUC5y+Mp3c4MiDlXb0w8ZHGX7s/IGIau13SSZadnUUN1rnyKnhsXrvLQtmcfugbJpVgEMj8oMpu4yPl0a5geM2v6+oSu+ZjmkaqlaL8REG7Orq+vz74sWuAVsdj/sS3ik5HiDOzb6H2vBG5+08fXLt1uIyGU8xgaRQelZcmKKA2A6r+NTO1oGC9LSKo8Mj9POiS7QMjXSQSKLsjucGgHM8QKfDANju0QwUROyS4NVRU0MKG7Wu0+mZwslVIV2BgHZ97ABao/t6dsV74kqarzYabHWzdUoYvjrc7m3aty+A+gQORO3tH9clZn4iNI+SJNEaameX7fh65l36nhyz5JcD/dD47Mm2ghMpV0IZzp884Fkblmmp+HCgrfn6jSmWl2boYDfMcSZDrDGx+8uYmnkckn6VqpoYuGmJBiqzDYsswhncx0nwL0z7B17Q07JBCphD/qfZnNBtg8D7+PQAPP2RH9RgaBfnQLU+Kq/M/e1edYSxlrHC9Pqajxi63bpfvJsDD70u8XPK+j4+CjAkK6gkzo6pGrOr5Ly7v82YU8teM9yxkjKETtKkJK6diyg26/+ptXrJYu7Vow+ETcOIs5EgBukcSgCL207Er5+Hv1wiSTkPwhOUNiEZXYL/A6GFsk36LJxBHWRz1Vi3fky8qv9MVSiGO7AF+NwX+E0u/DYWE4nJrTIT34307imiyD30q6bdh2zba7tw0yiePkCSBXzyxQw6XXkP0foDQFECHQC4pARggVEnRJoFUhhL0/CsOq50MoqKRHlE6kle7diHhZRej9uwiInarT0TL5Bb0/hqMOqQBqtbE+mHemBc+Pp2ha6fY7ABEt9kj2oKpAfj8lQQgoqoB600v9rDO/0A36poCGWNuyB52CD1W6TQEk6VpGWuhWr9mGop5Jt2cDYTQUaPYPG7+bo/vee53AiJx2jcIwayWfDJAA3EEa6U7mD+h2CoAuqw/tjy6sfjYMi33LZEnXMiw88EjJkFK6RZ29B+qZ9FtCQOjOqPstHpcE6JGSHxMzXsRklkDR7IuUDgpKpzH3LBoxUQP/RpUM9YkKAOgHJJms2gvNJmCQAQiKSmrp2hoteRs23XsuybonyMWbmwBPYE+nL2+foGvZ/hc3pXR9zN58TUz6vk+CekMGhY4yNe2pWzCsr7VrWVivOnojpZ7Zt+lGGnCH31Mf5epXQCWmLFdrx5ej6xrJIImKqXumS3A1Ax8dBdcNOAp6KdWuO27QjxG+Jj9VX/dl1NBNUvbNOmMbY+qMGTA+wtgMLktFULwOfkmrMTsD6qO0rqHTEu5Kd0kxX7Cx/X856Hu3o4sMto8pdH3QGfWLilt8F2B9Ij+kq6eFrtL9gzhm2OlcO7KqNnRFVSDo26QE6k6LPpAUx7/qFXs934Ey7E1Gl0Tluoc0QhdbVuq0q3arUL6qDm+H1SsZFnW6moFA49ym9aCtn41uh/1qtTC8K72b14LAGtt2yaU7IX0dLxy3YU9Tss4sd4beSDdpSjE+97xLuoJKv5TemA6IHnFU0JJPlnTo9nxIaiMFyIJ7SSZ0bM1BKS10z3VSvdvsT2APrpnYQFYIn2KBmO4CRNXzUb+nQFlBkgQkZzTGtMBnVnBRSAlddEOq+gXuJsvvKrMjt+FV++RCdVLsKQA9eDei+cVJtVDoTya51HwnndilDBgz8pNu1X646ESvMchf3Ul6y/I3rv2wgHQNYwEAH605KXSNDtHtZAipj36PhKJI7J7vKO1/DSWpTvobmx4tKYbGTep5Uv0/eg8EHnTh4PgOqJxube2fbmcXDc72BmmoJPvkT9v7O/nw+DSbvLnMPnKVlXyWoUKunlaiE4qViqBVVrLZfGVxX478B1sbO5X4a94rG+39t8mnvhhya6K4WW/t7YqiGNLJrooH9dYJOW/H4jh74mp7TxTD89XW8nZtsx0+prwqRigLjvgAe4JWrpPPnYhQeVPc3WvVN0nTJrt3U6y3N8XD78C2LIprOSZ3ZVNkB2/FXabXXFMUd1fCXnsi1eG2GJ4dhB0ZVsSYe5bwcnK5/GZeqGxW8vl8hTRk8/mV9irrt+jYEg8ji9gQ6SXnjUjHYX/9JXmGIGz342OHKe+tuCCzT4afKaQSakFYZT81MkKLB6xGl4jwIhOemvrbfLJBoPrPi2Iz7FcXDxdmu0E77Ih19tj689H6BnKH4snyrOUwGTcWDfXI2jbEcOTD2UzUuBgRwkKMnxWzEx43OEKC7oYovl10cajG28Tal09/SWyJ4vbyjHqOppiwVEqMCrEjiqfLbtt0VkfHrSX1b9OliOk6u+JuIqMsh0KUn4PMX+MwSY5JcyhuJqTZC+2W6nCp8w3xUDwMb8uK6+GACH+XLhmr+iMhyBxPDvrLIbc0xeV/nZRmSwwNjSqxFbvp5uZWPOObIrlhZ/Ewxq4SD9eTdNuiuPVICm0vYS4vCSLrI+//dulAKbajyUucpyieRIawvkcCzSElnxM3cgvxydHh+vr67mIAn6RbfzAvoo40CK6+fNFU/kq7Ow+1W4no0tAoiuuhfkmPtVDotug4C06E3WZ5e2dtEU+epLuanBYxsozvf8vmL0Hn5MNBJQNwkmipRMZMfagYKT5H1BnOAoccaW/Eg7BHzK4Z3/wk3bVFQErCofb82MifHZq4cDRLqcTEL/DZSUyqOApXqF9pUfVuUT+3Kh6G4xOzW2aKT9ElcejJdGLtq5F/Aax+Nda7D7xkOzkca+GlbdqUp6Z9SL12M849/55nprFt5RuiPNn+nCgvEmUmX47pcDn62gmbulqYF2TDCbvFdExczioLYvvxiPw9upRWolteE7TQs698j+hLjPLNwnhpDaQdJHxJJRwMp87MzDlgxOrM6KjVx4E0lDcb84jtIbuY+AJj04xbE7OUdgjzOidKWF8UNOa9ifTrHEbZXhxJSQa0E36yHvkw+pyEsase2UU+zqDJQSh4rLxs0u0tSwSaVaxFQ3xaJz/CTKeySL5fFG3qccukktk5CINSnuh3lWjI2TmMzMvZpZVRfp0pNye+ici0os9ITjoxtsqVcjOeDIThMl8sL1WdJ0HtYH8ll6us0WxFE0/yrPOLT12G3P56WJbuxkZ8usnOD/YjYbW1Q1a2Um2+rb9502bObC00isr6+sHeftY53XtDc4ylqW6svlk/aG2E1eUGuXrQPo2UWqkfhP/lOrFfLSyU69+lug8Z51dWVrKJOJCj54kODumQ++q2JTT2lx44jvP4ypPIkifm4+LiL57O8dz4k5CvffPkT5q1v3joa6LtvCXTM9tq0Una1rJkUufqzagqd5qrdHaWmafaaFEnu0EN36Gtq06Z+LOVejPy9pVtllTuN9uEapP93Gpu/WC0s3UaTFp5bZVwWdXyJJHMNvOxZ9XYweoa4ZhvOnRNgB4KOcr/ZHWHDFGltR3NxXKzTB1587RMKJ44J6Rz6235B6MrrNGg0MoJ9SXdvfVFoKB08ydNos2V9spmPkl3dXu3/JBuJUG3Tg2gtfPD0d2gtpivt2jSWK7XyVl2fyXOhTTKa3+n0iIJYHuNVv37LWrutJhoCU1izBWmeorKW6FOPtrMjOsCuUVor239aL/6NRr+UCwncjNa8mocelgXzdGWzWHDsi9r1rRHxxwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHN8b/w8xZ864BMj9DAAAAABJRU5ErkJggg==', // <-- replace with your real logo link
                  height: 120,
                  width: 120,
                  fit: BoxFit.cover,
                ),
              ),
              const SizedBox(height: 30),

              // Welcome Text
              Text(
                'Welcome to\nCosmetic Online Shop',
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                  height: 1.3,
                ),
              ),

              const SizedBox(height: 40),

              // Start Button
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => CosmeticListScreen()),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 50, vertical: 18),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                  elevation: 8,
                  shadowColor: Colors.white.withOpacity(0.4),
                ),
                child: const Text(
                  'Let\'s Start',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.lightBlueAccent,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
