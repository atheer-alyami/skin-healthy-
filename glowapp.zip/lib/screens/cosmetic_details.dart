import 'package:flutter/material.dart';

class CosmeticDetailsScreen extends StatelessWidget {
  final cosmeticModel;
  const CosmeticDetailsScreen(this.cosmeticModel, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: (Text(cosmeticModel.name)),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(child: Image.network(cosmeticModel.pictureURL)),
            Padding(
              padding: const EdgeInsets.all(8),
              child: Text(
                cosmeticModel.cosmeticPrice.toString(),
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 17, fontStyle: FontStyle.italic),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8),
              child: Text(
                cosmeticModel.details,
                textAlign: TextAlign.justify,
                style: TextStyle(
                  fontSize: 22,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
