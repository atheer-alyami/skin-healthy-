import 'package:flutter/material.dart';
import 'history.dart';
import 'scan_screen.dart';
import 'settings_screen.dart';
import 'myreport.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;
  String username = "User"; // Username for the welcome message

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color(0xFFE4D4C4), // Overall UI background color
        body: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.only(top: 40, left: 20),
                child: Image.network(
                  'https://cdn.builder.io/api/v1/image/assets/acca3a4cde154c34821b1cefa8b761e7/f7f837660d37c94527e84ed2001c6531d1556828dafdc65c14277093154590b0?placeholderIfAbsent=true',
                  height: 50,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 20, left: 20),
                child: Text(
                  'Welcome, $username',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
              ),
              SizedBox(height: 90),
              Column(
                children: [
                  Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        // My Reports Button
                        ElevatedButton.icon(
                          icon: ImageIcon(
                            NetworkImage(
                                'https://cdn.builder.io/api/v1/image/assets/acca3a4cde154c34821b1cefa8b761e7/3729e1f4d5c29c2943fe9294c4ff9d6a6c242095ea231c67506276901ab6f3dc?placeholderIfAbsent=true'),
                            size: 50,
                            color: Colors.white,
                          ),
                          label: Text(
                            'My Reports',
                            style: TextStyle(color: Colors.white, fontSize: 22),
                          ),
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => UserHistory()),
                            );
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Color(0xFF63422D),
                            padding: EdgeInsets.symmetric(
                                horizontal: 30, vertical: 15),
                            minimumSize: Size(200, 50),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                        SizedBox(height: 40),
                        // Settings Button
                        ElevatedButton.icon(
                          icon: ImageIcon(
                            NetworkImage(
                                'https://cdn.builder.io/api/v1/image/assets/acca3a4cde154c34821b1cefa8b761e7/22f423e753c09dd6a3965a848d401f0fe1b6e652170947ef7225d9b5a910b28a?placeholderIfAbsent=true'),
                            size: 50,
                            color: Colors.white,
                          ),
                          label: Text(
                            'Settings     ',
                            style: TextStyle(color: Colors.white, fontSize: 22),
                          ),
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => SettingsScreen()),
                            );
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Color(0xFF63422D),
                            padding: EdgeInsets.symmetric(
                                horizontal: 30, vertical: 15),
                            minimumSize: Size(200, 50),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        bottomNavigationBar: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            child: BottomNavigationBar(
              backgroundColor: Color(0xFFE4D4C4),
              selectedItemColor: Color(0xFF63422D),
              unselectedItemColor: Colors.grey,
              currentIndex: _selectedIndex,
              onTap: _onItemTapped,
              items: [
                BottomNavigationBarItem(
                  icon: Container(
                    padding: EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: _selectedIndex == 0
                          ? Color(0xFF63422D)
                          : Colors.transparent,
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.home,
                      size: 30,
                      color: _selectedIndex == 0 ? Colors.white : Colors.grey,
                    ),
                  ),
                  label: 'Home',
                ),
                BottomNavigationBarItem(
                  icon: InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => ScanScreen()),
                      );
                    },
                    child: Container(
                      padding: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: _selectedIndex == 0
                            ? Color(0xFF63422D)
                            : Colors.transparent,
                        shape: BoxShape.circle,
                      ),
                      child: ImageIcon(
                        NetworkImage(
                            'https://static-00.iconduck.com/assets.00/scan-icon-2048x2046-wnzre3p3.png'),
                        size: 30,
                        color: _selectedIndex == 1 ? Colors.white : Colors.grey,
                      ),
                    ),
                  ),
                  label: 'Scan',
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
