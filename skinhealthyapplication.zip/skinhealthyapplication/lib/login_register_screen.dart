import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'register_screen.dart';
import 'login.dart';
import 'home_screen.dart'; // Make sure you have this import

class LoginAndSignUpScreen extends StatelessWidget {
  const LoginAndSignUpScreen({Key? key}) : super(key: key);

  // Google Sign-In method
  Future<UserCredential> signInWithGoogle() async {
    try {
      // Trigger the authentication flow
      final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();

      // Check if user cancelled the sign-in
      if (googleUser == null) {
        throw FirebaseAuthException(
          code: 'ERROR_ABORTED_BY_USER',
          message: 'Sign in aborted by user',
        );
      }

      // Obtain the auth details from the request
      final GoogleSignInAuthentication googleAuth =
          await googleUser.authentication;

      // Create a new credential
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      // Sign in to Firebase with the Google credentials
      return await FirebaseAuth.instance.signInWithCredential(credential);
    } catch (e) {
      // Handle any errors that occur during the sign-in process
      rethrow;
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SingleChildScrollView(
          child: Center(
            child: Container(
              constraints: const BoxConstraints(maxWidth: 480),
              padding: const EdgeInsets.only(bottom: 9),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // Header Section
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.only(top: 28),
                    decoration: const BoxDecoration(
                      color: Color.fromRGBO(228, 212, 196, 0.22),
                    ),
                    child: Column(
                      children: [
                        SizedBox(
                          width: 429,
                          child: Text(
                            'Health and\nBeauty Companion',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 24,
                              fontFamily: 'Sora',
                            ),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Text(
                          'The Glow you seek is one treatment away',
                          style: TextStyle(
                            color: const Color(0xFF010101),
                            fontSize: 16,
                            fontFamily: 'SourceSerif4',
                          ),
                        ),
                        const SizedBox(height: 15),
                        AspectRatio(
                          aspectRatio: 1.11,
                          child: Image.network(
                            'https://cdn.builder.io/api/v1/image/assets/TEMP/0a2bbe8e1201bff5763b3adae6a0939163d0a2acaa957910f2c1b8fd4ac51542?placeholderIfAbsent=true&apiKey=acca3a4cde154c34821b1cefa8b761e7',
                            fit: BoxFit.contain,
                            width: double.infinity,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 48),
                  Text(
                    'Your skin journey start here!',
                    style: TextStyle(
                      color: const Color(0xFF010101),
                      fontSize: 24,
                      fontFamily: 'SourceSerif4',
                      fontWeight: FontWeight.w500,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 44),

                  // Login Buttons Section
                  Container(
                    constraints: const BoxConstraints(maxWidth: 299),
                    child: Column(
                      children: [
                        const SizedBox(height: 12),
                        _buildEmailLoginButton(context),
                        const SizedBox(height: 12),
                        _buildGoogleLoginButton(context),
                      ],
                    ),
                  ),

                  // Sign Up Option
                  const SizedBox(height: 19),
                  InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => SignUpScreen()),
                      );
                    },
                    child: RichText(
                      text: TextSpan(
                        style: TextStyle(
                          color: const Color(0xFF4A3F39),
                          fontSize: 14,
                          fontFamily: 'Inter',
                          height: 1,
                        ),
                        children: [
                          const TextSpan(text: 'Or '),
                          TextSpan(
                            text: 'Create new account',
                            style: TextStyle(
                              fontWeight: FontWeight.w600,
                              decoration: TextDecoration.underline,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 38),
                  Container(
                    width: 139,
                    height: 5,
                    decoration: BoxDecoration(
                      color: Colors.black,
                      borderRadius: BorderRadius.circular(100),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildEmailLoginButton(BuildContext context) {
    return Container(
      height: 48,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(27),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: TextButton(
        style: TextButton.styleFrom(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(27),
          ),
        ),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => LoginScreen()),
          );
        },
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.email_outlined,
              color: Colors.grey[700],
              size: 24,
            ),
            const SizedBox(width: 12),
            Text(
              'Log in with Email',
              style: TextStyle(
                color: const Color(0xFF4A3F39),
                fontSize: 16,
                fontFamily: 'Inter',
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGoogleLoginButton(BuildContext context) {
    return Container(
      height: 48,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(27),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: TextButton(
        style: TextButton.styleFrom(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(27),
          ),
        ),
        onPressed: () async {
          try {
            // Show loading indicator
            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (BuildContext context) {
                return const Center(
                  child: CircularProgressIndicator(),
                );
              },
            );

            // Sign in with Google
            await signInWithGoogle();

            // Close loading indicator
            Navigator.of(context).pop();

            // Navigate to HomeScreen after successful login
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => HomeScreen()),
            );
          } catch (e) {
            // Close loading indicator
            Navigator.of(context).pop();

            // Show error message
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Error signing in: ${e.toString()}'),
                backgroundColor: Colors.red,
              ),
            );
          }
        },
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 24,
              height: 24,
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: NetworkImage(
                    'https://cdn-icons-png.flaticon.com/512/720/720255.png',
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Text(
              'Log in with Google',
              style: TextStyle(
                color: const Color(0xFF4A3F39),
                fontSize: 16,
                fontFamily: 'Inter',
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
