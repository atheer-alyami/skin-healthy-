class Disease {
  final String name;
  final String description;
  final List<String> treatments;
  final List<RecommendedProduct> recommendedProducts;

  Disease({
    required this.name,
    required this.description,
    required this.treatments,
    required this.recommendedProducts,
  });
}

class RecommendedProduct {
  final String ageGroup;
  final String name;
  final String imageUrl;

  RecommendedProduct({
    required this.ageGroup,
    required this.name,
    required this.imageUrl,
  });
}

final List<Disease> diseases = [
  Disease(
    name: "Acne",
    description:
        "Acne is a skin condition that occurs when pores become clogged with oils and dead skin cells, leading to the appearance of pimples, blackheads, or whiteheads. It commonly occurs on the face, chest, and back.",
    treatments: [
      "Wash your face with a gentle cleanser.",
      "Avoid touching or squeezing pimples.",
      "Use mild products.",
      "Keep your skin hydrated by using a lightweight, oil-free moisturizer."
    ],
    recommendedProducts: [
      RecommendedProduct(
        ageGroup: "For kids (ages 6 to 12)",
        name: "CeraVe Hydrating Cleanser",
        imageUrl:
            "https://m.media-amazon.com/images/I/61x370WEbLL._AC_SX679_.jpg",
      ),
      RecommendedProduct(
        ageGroup: "For teenagers (ages 13 to 19)",
        name: "La Roche-Posay Effaclar Gel Cleanser",
        imageUrl:
            "https://m.media-amazon.com/images/I/51LNgQfopSL._AC_UF1000,1000_QL80_.jpg",
      ),
      RecommendedProduct(
        ageGroup: "For adults (ages 20 and above)",
        name: "Neutrogena Hydro Boost Water Gel",
        imageUrl:
            "https://images.ctfassets.net/hpl1ps3eket1/J1YaWqlPTtpRy8l5ZjKFh/406e9a7713472285a142b3c2e3e8a357/1.png",
      ),
    ],
  ),
  Disease(
    name: "Actinic_Keratosis",
    description:
        "Actinic keratosis is a precancerous skin condition caused by long-term exposure to ultraviolet (UV) radiation from the sun or tanning beds. It appears as rough, scaly patches or crusty growths on sun-exposed areas such as the face, scalp, ears, hands, and arms. The affected areas may be red, pink, or flesh-colored and can sometimes be itchy or sensitive to touch. If left untreated, actinic keratosis can develop into squamous cell carcinoma, a type of skin cancer.",
    treatments: [
      "Limit sun exposure, especially during peak hours (10 AM – 4 PM).",
      "Apply broad-spectrum sunscreen (SPF 30 or higher) daily, even on cloudy days.",
      "Wear protective clothing, such as hats and long sleeves, when outdoors."
    ],
    recommendedProducts: [
      RecommendedProduct(
        ageGroup: "For kids (ages 6 to 12)",
        name: "EltaMD UV Pure Broad-Spectrum SPF 47",
        imageUrl:
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTpZyAyNqXEwjNlAyspdS7kmiMk6KGlY1mWRdCwaOygwrybbwQb",
      ),
      RecommendedProduct(
        ageGroup: "For teenagers (ages 13 to 19)",
        name: "La Roche-Posay Anthelios Melt-in Sunscreen SPF 60",
        imageUrl:
            "https://m.media-amazon.com/images/I/61qA+KLguKL._AC_UF1000,1000_QL80_.jpg",
      ),
      RecommendedProduct(
        ageGroup: "For adults (ages 20 and above)",
        name: "ISDIN Eryfotona Actinica SPF 50+",
        imageUrl:
            "https://m.media-amazon.com/images/I/61L3Pw-sBUL._AC_UF1000,1000_QL80_.jpg",
      ),
    ],
  ),
  Disease(
    name: "Benign_tumors",
    description:
        "Benign tumors are non-cancerous growths that develop in various tissues of the body. Unlike malignant tumors, they do not spread to other parts of the body. These tumors can form in the skin, muscles, fat, or internal organs and are usually slow-growing. They may appear as lumps under the skin, discolorations, or abnormal tissue growths. While most benign tumors are harmless, some can cause discomfort, pressure on surrounding tissues, or cosmetic concerns, requiring medical attention.",
    treatments: [
      "Monitor the tumor for changes in size, shape, or color.",
      "Avoid pressing or irritating the affected area.",
      "Maintain a healthy lifestyle to support overall skin and tissue health.",
      "In cases where the tumor causes pain or affects function, consult a doctor for removal options, such as surgery, laser treatment, or medication."
    ],
    recommendedProducts: [
      RecommendedProduct(
        ageGroup: "For kids (ages 6 to 12)",
        name: "CeraVe Hydrating Cleanser",
        imageUrl:
            "https://www.cerave.eg/-/media/project/loreal/brand-sites/cerave/americas/eg/latest_pdp_images/hyderating-facial-cleanser/hydrating-cleanser-236ml-sm.jpg?rev=-1",
      ),
      RecommendedProduct(
        ageGroup: "For teenagers (ages 13 to 19)",
        name: "La Roche-Posay Effaclar Gel Cleanser",
        imageUrl:
            "https://africa.laroche-posay.com/-/media/project/loreal/brand-sites/lrp/emea/za/products/effaclar/effaclar-cleansing-foaming-gel/la-roche-posay-face-cleanser-effaclar-cleansing-foaming-gel-200ml-3337872411083-front.png",
      ),
      RecommendedProduct(
        ageGroup: "For adults (ages 20 and above)",
        name: "Neutrogena Hydro Boost Water Gel",
        imageUrl:
            "https://images-eu.ssl-images-amazon.com/images/I/71VDe1xU67L._AC_UL300_SR205,300_.jpg",
      ),
    ],
  ),
  Disease(
    name: "Bullous",
    description:
        "Bullous disorders are a group of skin conditions characterized by the formation of fluid-filled blisters (bullae) on the skin and mucous membranes. These blisters can vary in size and may be caused by autoimmune diseases, infections, genetic factors, or allergic reactions. Common types include bullous pemphigoid, pemphigus vulgaris, and epidermolysis bullosa. Symptoms may include itching, pain, and skin fragility. If left untreated, severe cases can lead to infections and complications.",
    treatments: [
      "Avoid scratching or popping blisters to prevent infections.",
      "Keep the affected skin clean and dry.",
      "Use gentle, fragrance-free skincare products."
    ],
    recommendedProducts: [
      RecommendedProduct(
        ageGroup: "For kids (ages 6 to 12)",
        name: "Vanicream Gentle Facial Cleanser",
        imageUrl:
            "https://cloudinary.images-iherb.com/image/upload/f_auto,q_auto:eco/images/vnc/vnc32208/r/12.jpg",
      ),
      RecommendedProduct(
        ageGroup: "For teenagers (ages 13 to 19)",
        name: "Bioderma Sébium Foaming Gel",
        imageUrl:
            "https://www.mumzworld.com/media/catalog/product/cache/abbe87547126054a260ab1dcf2fa50de/b/d/bd-3401353791220.jpg?format=jpeg",
      ),
      RecommendedProduct(
        ageGroup: "For adults (ages 20 and above)",
        name: "Clinique Moisture Surge 100H Auto-Replenishing Hydrator",
        imageUrl:
            "https://m.media-amazon.com/images/I/61HAWSVPX-L._AC_UF350,350_QL50_.jpg",
      ),
    ],
  ),
  Disease(
    name: "Candidiasis",
    description:
        "Candidiasis is a common fungal infection caused by the overgrowth of Candida species, particularly Candida albicans. It can affect various parts of the body, including the skin, mouth, throat. The condition often develops in warm, moist environments and may present as redness, itching, white patches, or discomfort in the affected area. Factors like a weakened immune system, antibiotic use, or poor hygiene can contribute to its occurrence.",
    treatments: [
      "Maintain proper hygiene and keep affected areas dry.",
      "Wear breathable, cotton clothing to prevent moisture buildup.",
      "Use gentle cleansers and antifungal creams to manage symptoms."
    ],
    recommendedProducts: [
      RecommendedProduct(
        ageGroup: "For Children (6-12 years old)",
        name: "CeraVe Hydrating Cleanser",
        imageUrl:
            "https://encrypted-tbn0.gstatic.com/shopping?q=tbn:ANd9GcSGtEaV8QdZH0sz7VeXXZQAf-_wqGkFVd4NoofMgqX9J-BQ2Fzy-aIxjTwNCz5pQeRiv7ASRn2i0zayPtevBUXsN7_TufVOuRAIaAzAlJRzmccMep4a_4Se&usqp=CAE",
      ),
      RecommendedProduct(
        ageGroup: "For Teenagers (13-19 years old)",
        name: "Canesten Cream",
        imageUrl:
            "https://rakizah.com/cdn/shop/files/315023004_02a9bfbf-b8a7-46fe-8e2d-1dd9c9a60b3a.jpg?v=1720875235&width=1200",
      ),
      RecommendedProduct(
        ageGroup: "For Adults (20 years and older)",
        name: "Lamisil Cream",
        imageUrl:
            "https://encrypted-tbn0.gstatic.com/shopping?q=tbn:ANd9GcRn3-OsOaVvhJJIh0UI7U4qq9KVvkBuOdInERMaPggdbH3pjsK4mJwPAPWRWD4ZQjhLpHzElFUQbhUVRI0cn3qsohDdSmRBYhZ1uz7lTGEf6MDWJQFBcGAZ6WQ&usqp=CAc",
      ),
    ],
  ),
  Disease(
    name: "DrugEruption",
    description:
        "A drug eruption is a skin reaction caused by sensitivity to certain medications, resulting in redness, rash, itching, or swelling. These reactions can vary in severity and may disappear after discontinuing the medication.",
    treatments: [
      "Stop using the suspected medication and consult a doctor.",
      "Apply soothing and hypoallergenic moisturizers to reduce irritation.",
      "Avoid harsh skincare products that may worsen sensitivity."
    ],
    recommendedProducts: [
      RecommendedProduct(
        ageGroup: "For Children (6-12 years old)",
        name: "Aveeno Baby Eczema Therapy",
        imageUrl:
            "https://cloudinary.images-iherb.com/image/upload/f_auto,q_auto:eco/images/erc/erc00323/v/38.jpg",
      ),
      RecommendedProduct(
        ageGroup: "For Teenagers (13-19 years old)",
        name: "Cetaphil Hydrating Lotion",
        imageUrl:
            "https://www.marka.sa/image/cache/catalog/1682522717RhEIjKAsmIizc4mKsZoq9bMaIPCQAkrueeORWMw4-1024x1024.webp",
      ),
      RecommendedProduct(
        ageGroup: "For Adults (20 years and older)",
        name: "La Roche-Posay Cicaplast Baume B5",
        imageUrl:
            "https://cdn.salla.sa/onxjbX/022ee2f2-d702-482f-8309-206d711a286a-1000x1000-HxaqWubqLGtdbYjmoYk7uvZHE2m518afVw85HcxA.jpg",
      ),
    ],
  ),
  Disease(
    name: "Eczema",
    description:
        "Eczema is a common skin condition characterized by inflamed, itchy, and red patches of skin. It is often caused by environmental triggers, allergens, or an overactive immune system. Eczema can appear in different forms, such as atopic dermatitis, contact dermatitis, or seborrheic dermatitis.",
    treatments: [
      "Use fragrance-free, gentle cleansers and moisturizers to help maintain skin hydration and reduce flare-ups.",
      "Avoid scratching affected areas to prevent further irritation and infection."
    ],
    recommendedProducts: [
      RecommendedProduct(
        ageGroup: "For Children (6-12 years old)",
        name: "Aveeno Baby Eczema Therapy Moisturizing Cream",
        imageUrl:
            "https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcQVv8Fav1jRlDKYH5VKGGmjDRHTWzwgGeTHyleSsen30WAfC9fR7EgT0b-5brj1y7d1rDqKYFFJExSdaJcaDFa3lYybAl5ABla9K8WkRz_37InBe-2Twd9kE-I9MlrRa39f7yF5OWJe&usqp=CAc",
      ),
      RecommendedProduct(
        ageGroup: "For Teenagers (13-19 years old)",
        name: "CeraVe Eczema Relief Cream",
        imageUrl:
            "https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcSiYu7CA5kEJmUenNrKL2qTghQzz9oF1VdHaHsJVO0H_CseMTMSJTArywLrqZMLYn2tOAGA3wLels6Z2XHGibQKdS8WgdjY9BZ-ltr890HgIlbCzkNoGWdoyfhj9uyaOzgo6P3eomJpIXZ4&usqp=CAc",
      ),
      RecommendedProduct(
        ageGroup: "For Adults (20 years and older)",
        name: "Eucerin Eczema Relief Body Cream",
        imageUrl: "https://m.media-amazon.com/images/I/61kOojGpQ2L.jpg",
      ),
    ],
  ),
];
