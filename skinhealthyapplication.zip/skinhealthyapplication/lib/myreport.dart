import 'package:flutter/material.dart';
import 'dart:io';

import 'model/disease_model.dart';

class MyReport extends StatelessWidget {
  final Disease disease;
  final File imageFile;

  const MyReport({
    Key? key,
    required this.disease,
    required this.imageFile,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        child: Container(
          color: Colors.white,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Align(
                  alignment: Alignment.centerLeft,
                  child: IconButton(
                    icon: const Icon(Icons.arrow_back_ios),
                    color: Color(0xFF63422D),
                    onPressed: () => Navigator.pop(context),
                  ),
                ),
                SizedBox(height: 30),
                Image.network(
                  'https://cdn.builder.io/api/v1/image/assets/acca3a4cde154c34821b1cefa8b761e7/f7f837660d37c94527e84ed2001c6531d1556828dafdc65c14277093154590b0?placeholderIfAbsent=true',
                  width: 76,
                  fit: BoxFit.contain,
                ),
                SizedBox(height: 20),
                Padding(
                  padding: const EdgeInsets.only(left: 13),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'My Report',
                        style: TextStyle(
                          fontFamily: 'Roboto',
                          fontSize: 24,
                          color: Color(0xFF4A3F39),
                          fontWeight: FontWeight.w700,
                          letterSpacing: -1,
                        ),
                      ),
                      Container(
                        width: 24,
                        height: 24,
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 32),
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.file(
                    imageFile,
                    width: double.infinity,
                    height: 250,
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(height: 13),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 7),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${disease.name} Description',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 20,
                          fontFamily: 'Roboto',
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      SizedBox(height: 15),
                      Container(
                        width: double.infinity,
                        padding: EdgeInsets.all(19),
                        decoration: BoxDecoration(
                          color: Color(0x38E4D4C4),
                        ),
                        child: Text(
                          disease.description,
                          style: TextStyle(
                            fontFamily: 'Roboto',
                            fontSize: 20,
                            color: Colors.black,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ),
                      SizedBox(height: 34),
                      Container(
                        width: double.infinity,
                        padding: EdgeInsets.fromLTRB(7, 18, 7, 9),
                        decoration: BoxDecoration(
                          color: Color(0x38E4D4C4),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: disease.treatments
                              .map(
                                (treatment) => Text(
                                  '• $treatment',
                                  style: TextStyle(
                                    fontFamily: 'Roboto',
                                    fontSize: 20,
                                    color: Colors.black,
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              )
                              .toList(),
                        ),
                      ),
                      if (disease.recommendedProducts.isNotEmpty) ...[
                        SizedBox(height: 20),
                        Padding(
                          padding: const EdgeInsets.only(left: 14),
                          child: Text(
                            'Recommended Products',
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 20,
                              fontFamily: 'Roboto',
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                        SizedBox(height: 4),
                        Container(
                          width: double.infinity,
                          padding: EdgeInsets.only(top: 9),
                          decoration: BoxDecoration(
                            color: Color(0x38E4D4C4),
                          ),
                          child: Column(
                            children: disease.recommendedProducts
                                .map(
                                  (product) => Padding(
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 10),
                                    child: Column(
                                      children: [
                                        Text(
                                          product.ageGroup,
                                          style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 20,
                                            fontFamily: 'Roboto',
                                            fontWeight: FontWeight.w400,
                                          ),
                                        ),
                                        SizedBox(height: 10),
                                        Row(
                                          children: [
                                            Expanded(
                                              child: Text(
                                                product.name,
                                                style: TextStyle(
                                                  color: Colors.blue,
                                                  fontSize: 20,
                                                  fontFamily: 'Roboto',
                                                  fontWeight: FontWeight.w400,
                                                ),
                                              ),
                                            ),
                                            SizedBox(width: 10),
                                            Image.network(
                                              product.imageUrl,
                                              width: 90,
                                              height: 90,
                                              fit: BoxFit.contain,
                                            ),
                                          ],
                                        ),
                                        SizedBox(height: 20),
                                      ],
                                    ),
                                  ),
                                )
                                .toList(),
                          ),
                        ),
                      ],
                      SizedBox(height: 20),
                      Container(
                        color: Colors.white,
                        padding:
                            EdgeInsets.symmetric(horizontal: 79, vertical: 10),
                        child: Center(
                          child: Container(
                            width: 139,
                            height: 5,
                            decoration: BoxDecoration(
                              color: Colors.black,
                              borderRadius: BorderRadius.circular(100),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
