import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'widgets/InstructionCard.dart';
import 'widgets/HomeIndicator.dart';
import 'detect_screen.dart';

class ScanScreen extends StatelessWidget {
  const ScanScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          leading: GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 28,
              height: 28,
              child: Icon(
                Icons.arrow_back_ios,
                size: 16,
                color: Color(0xFF4A3F39),
              ),
            ),
          ),
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color(0xFFF4F0EF),
                    Colors.white,
                    Color(0xFFF4F0EF),
                  ],
                  stops: [0.0, 0.465, 1.0],
                ),
              ),
              child: Stack(
                children: [
                  Padding(
                    padding: EdgeInsets.fromLTRB(20, 20, 20, 50),
                    child: Column(
                      children: [
                        SizedBox(height: 40),
                        Text(
                          'Scan your area',
                          style: GoogleFonts.roboto(
                            fontSize: 24,
                            fontWeight: FontWeight.w600,
                            color: Color(0xFF63422D),
                          ),
                        ),
                        SizedBox(height: 10),
                        Text(
                          'One click away from personalized skincare insights',
                          textAlign: TextAlign.center,
                          style: GoogleFonts.roboto(
                            fontSize: 20,
                            fontWeight: FontWeight.w400,
                            color: Color(0xFF63422D),
                          ),
                        ),
                        SizedBox(height: 40),
                        InstructionCard(),
                        SizedBox(height: 40),
                        ElevatedButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => DetectionScreen(),
                              ),
                            );
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Color(0xE063422D),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                            minimumSize: Size(double.infinity, 48),
                          ),
                          child: Text(
                            'Get started',
                            style: GoogleFonts.inter(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 100)
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
