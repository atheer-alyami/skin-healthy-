import 'package:flutter/material.dart';
import 'auth_Screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(seconds: 2), () {
      if (mounted) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (context) => AuthScreen()),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SafeArea(
          child: Stack(
            fit: StackFit.expand,
            children: [
              // Background Image
              Image.network(
                "https://cdn.builder.io/api/v1/image/assets/TEMP/b237166f54e72e7f72deacb3a10aa5a4fa7304f39a346b1e8b5515cbe8d878a0?placeholderIfAbsent=true&apiKey=acca3a4cde154c34821b1cefa8b761e7",
                fit: BoxFit.cover,
              ),

              // Overlay with text
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text(
                    "Health and\nBeauty Companion",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 32,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
