import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'colors.dart';

class AppTextStyles {
  static TextStyle title = GoogleFonts.robotoCondensed(
    fontSize: 32,
    fontWeight: FontWeight.w700,
    color: AppColors.primaryText,
    height: 1.3,
    letterSpacing: -0.32,
  );

  static TextStyle description = GoogleFonts.inter(
    fontSize: 16,
    fontWeight: FontWeight.w400,
    color: AppColors.secondaryText,
    height: 1.25,
  );

  static TextStyle inputLabel = GoogleFonts.inter(
    fontSize: 14,
    fontWeight: FontWeight.w400,
    color: AppColors.primaryText,
  );

  static TextStyle inputText = GoogleFonts.inter(
    fontSize: 16,
    fontWeight: FontWeight.w400,
    color: AppColors.black,
  );

  static TextStyle buttonText = GoogleFonts.acme(
    fontSize: 24,
    fontWeight: FontWeight.w400,
    color: AppColors.white,
  );
}
