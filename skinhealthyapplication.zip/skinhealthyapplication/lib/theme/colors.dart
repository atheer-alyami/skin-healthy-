import 'package:flutter/material.dart';

class AppColors {
  static const Color background = Color(0xFFE4D4C4);
  static const Color primaryBrown = Color(0xFF63422D);
  static const Color textBrown = Color(0xFF4A3F39);
  static const Color backgroundBeige = Color(0x38E4D4C4);
  static const Color borderGrey = Color(0xFFD8DADC);
  static const Color white = Color(0xFFFFFFFF);
  static const Color black = Color(0xFF000000);
  static const Color primaryText = Color(0xFF4A3F39);
  static const Color secondaryText = Color(0xFF474646);
  static const Color inputBorder = Color(0xFFD8DADC);
  static const Color buttonBackground = Color(0xE063422D);
}
