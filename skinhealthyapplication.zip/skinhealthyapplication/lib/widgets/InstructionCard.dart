import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'InstructionItem.dart';

class InstructionCard extends StatelessWidget {
  const InstructionCard({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.white.withOpacity(0.5),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            offset: Offset(0, 4),
            blurRadius: 4,
          ),
        ],
      ),
      child: Column(
        children: [
          Text(
            'Snap, Scan, Transform!',
            style: GoogleFonts.inter(
              fontSize: 18,
              fontWeight: FontWeight.w500,
              color: Color(0xFF63422D),
            ),
          ),
          SizedBox(height: 30),
          InstructionItem(
            icon: Icons.check_circle_outline,
            text: 'Prepare your affected area',
          ),
          SizedBox(height: 20),
          InstructionItem(
            icon: Icons.do_not_disturb,
            text: 'Do not apply any products',
          ),
          SizedBox(height: 20),
          InstructionItem(
            icon: Icons.wb_sunny_outlined,
            text: 'Sit in a good lighting',
          ),
          SizedBox(height: 20),
          InstructionItem(
            icon: Icons.person_outline,
            text: 'Stay still for a few seconds.',
          ),
        ],
      ),
    );
  }
}
