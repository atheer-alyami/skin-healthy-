import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class InstructionItem extends StatelessWidget {
  final IconData icon;
  final String text;

  const InstructionItem({
    Key? key,
    required this.icon,
    required this.text,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            color: Color(0xE063422D),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(
            icon,
            color: Colors.white,
            size: 20,
          ),
        ),
        SizedBox(width: 12),
        Expanded(
          child: Text(
            text,
            style: GoogleFonts.inter(
              fontSize: 16,
              fontWeight: FontWeight.w400,
              color: Color(0xE063422D),
              height: 1.375,
            ),
          ),
        ),
      ],
    );
  }
}
