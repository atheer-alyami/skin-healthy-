import 'package:flutter/material.dart';

class SettingsListItem extends StatelessWidget {
  final String icon;
  final String title;

  const SettingsListItem({
    Key? key,
    required this.icon,
    required this.title,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: Image.network(
            icon,
            width: 32,
            height: 32,
            fit: BoxFit.contain,
          ),
        ),
        SizedBox(width: 12),
        Padding(
          padding: EdgeInsets.only(top: 8),
          child: Text(
            title,
            style: TextStyle(
              fontSize: 15,
              color: Color(0xFF646464),
            ),
          ),
        ),
      ],
    );
  }
}
