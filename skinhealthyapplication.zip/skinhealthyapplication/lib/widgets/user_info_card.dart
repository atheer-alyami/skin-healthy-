import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_fonts/google_fonts.dart';

class UserInfoCard extends StatefulWidget {
  const UserInfoCard({Key? key}) : super(key: key);

  @override
  _UserInfoCardState createState() => _UserInfoCardState();
}

class _UserInfoCardState extends State<UserInfoCard> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  String? userEmail;
  String? userId;
  bool isLoading = true;
  bool isUpdating = false;
  TextEditingController ageController = TextEditingController();
  TextEditingController phoneController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    try {
      final User? user = _auth.currentUser;
      if (user != null) {
        setState(() {
          userEmail = user.email;
          userId = user.uid;
        });

        final DocumentSnapshot userDoc =
            await _firestore.collection('users').doc(userId).get();

        if (userDoc.exists) {
          setState(() {
            ageController.text = userDoc['age']?.toString() ?? '';
            phoneController.text = userDoc['phone']?.toString() ?? '';
          });
        }
      }
    } catch (e) {
      _showSnackBar('Error loading data', Colors.red);
    } finally {
      setState(() => isLoading = false);
    }
  }

  Future<void> _updateUserData() async {
    if (userId == null) return;

    setState(() => isUpdating = true);

    try {
      await _firestore.collection('users').doc(userId).set({
        'email': userEmail,
        'age': ageController.text,
        'phone': phoneController.text,
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      _showSnackBar('Profile updated successfully', Colors.green);
    } catch (e) {
      _showSnackBar('Failed to update profile', Colors.red);
    } finally {
      setState(() => isUpdating = false);
    }
  }

  void _showSnackBar(String message, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 337,
      padding: EdgeInsets.fromLTRB(24, 105, 24, 34),
      decoration: BoxDecoration(
        color: Color(0x38E4D4C4),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: Color(0x80FFFFFF),
        ),
        boxShadow: [
          BoxShadow(
            offset: Offset(-4, -4),
            blurRadius: 11,
            color: Color(0x33CDCDCD),
          ),
        ],
      ),
      child: isLoading
          ? Center(child: CircularProgressIndicator(color: Color(0xFF63422D)))
          : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '-Optional',
                  style: GoogleFonts.inter(
                    color: Colors.black,
                    fontSize: 10,
                  ),
                ),
                SizedBox(height: 24),
                Container(
                  width: 260,
                  padding: EdgeInsets.symmetric(vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(100),
                  ),
                  child: Row(
                    children: [
                      SizedBox(width: 16),
                      Icon(
                        Icons.email_outlined,
                        size: 20,
                        color: Colors.black,
                      ),
                      SizedBox(width: 16),
                      Expanded(
                        child: Text(
                          userEmail ?? 'No email available',
                          style: GoogleFonts.inter(
                            fontSize: 16,
                            color: Colors.black,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 24),
                Container(
                  padding: EdgeInsets.symmetric(vertical: 5, horizontal: 16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(100),
                  ),
                  child: TextField(
                    controller: ageController,
                    decoration: InputDecoration(
                      hintText: 'Enter your age',
                      border: InputBorder.none,
                      prefixIcon: Icon(Icons.person_outline),
                      labelText: 'Age',
                      labelStyle: GoogleFonts.inter(
                        fontSize: 14,
                        color: Colors.black54,
                      ),
                    ),
                    style: GoogleFonts.inter(
                      fontSize: 16,
                      color: Colors.black,
                    ),
                    keyboardType: TextInputType.number,
                  ),
                ),
                SizedBox(height: 24),
                Container(
                  padding: EdgeInsets.symmetric(vertical: 5, horizontal: 16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(100),
                  ),
                  child: TextField(
                    controller: phoneController,
                    decoration: InputDecoration(
                      hintText: '+966000000000',
                      border: InputBorder.none,
                      prefixIcon: Icon(Icons.phone_outlined),
                      labelText: 'Phone Number',
                      labelStyle: GoogleFonts.inter(
                        fontSize: 14,
                        color: Colors.black54,
                      ),
                    ),
                    style: GoogleFonts.inter(
                      fontSize: 16,
                      color: Colors.black,
                    ),
                    keyboardType: TextInputType.phone,
                  ),
                ),
                SizedBox(height: 32),
                ElevatedButton(
                  onPressed: isUpdating ? null : _updateUserData,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF63422D),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(100),
                    ),
                    minimumSize: Size(double.infinity, 48),
                    padding: EdgeInsets.symmetric(vertical: 12),
                  ),
                  child: isUpdating
                      ? SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 2,
                          ),
                        )
                      : Text(
                          'Update',
                          style: GoogleFonts.inter(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Colors.white,
                          ),
                        ),
                ),
              ],
            ),
    );
  }
}
